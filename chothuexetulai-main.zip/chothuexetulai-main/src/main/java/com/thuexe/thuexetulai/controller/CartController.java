package com.thuexe.thuexetulai.controller;

import com.thuexe.thuexetulai.model.Booking;
import com.thuexe.thuexetulai.model.Car;
import com.thuexe.thuexetulai.model.User;
import com.thuexe.thuexetulai.repository.BookingRepository;
import com.thuexe.thuexetulai.repository.CarRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@Controller
public class CartController {

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private BookingRepository bookingRepository;

    // 👉 THÊM VÀO GIỎ
    @GetMapping("/cart/add/{id}")
    public String addToCart(@PathVariable Long id, HttpSession session) {

        List<Car> cart = (List<Car>) session.getAttribute("cart");

        if (cart == null) {
            cart = new ArrayList<>();
        }

        Car car = carRepository.findById(id).orElse(null);

        if (car != null) {
            cart.add(car);
        }

        session.setAttribute("cart", cart);

        return "redirect:/cart";
    }

    // 👉 HIỂN THỊ GIỎ + TÍNH TIỀN
    @GetMapping("/cart")
    public String cartPage(HttpSession session,
                           @RequestParam(required = false) String startDate,
                           @RequestParam(required = false) String endDate,
                           Model model) {

        List<Car> cart = (List<Car>) session.getAttribute("cart");

        if (cart == null) {
            cart = new ArrayList<>();
        }

        long days = 1;

        if (startDate != null && endDate != null) {
            LocalDate start = LocalDate.parse(startDate);
            LocalDate end = LocalDate.parse(endDate);

            days = ChronoUnit.DAYS.between(start, end);
            if (days <= 0) days = 1;
        }

        double total = 0;
        for (Car car : cart) {
            total += car.getPrice() * days;
        }

        model.addAttribute("cart", cart);
        model.addAttribute("total", total);
        model.addAttribute("days", days);
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);

        return "cart";
    }

    // 👉 XÓA XE
    @GetMapping("/cart/remove/{id}")
    public String remove(@PathVariable Long id, HttpSession session) {

        List<Car> cart = (List<Car>) session.getAttribute("cart");

        if (cart != null) {
            cart.removeIf(c -> c.getId().equals(id));
        }

        session.setAttribute("cart", cart);

        return "redirect:/cart";
    }

    // 👉 ĐẶT TẤT CẢ
    @PostMapping("/cart/checkout")
    public String checkout(HttpSession session,
                           @RequestParam String startDate,
                           @RequestParam String endDate) {

        User user = (User) session.getAttribute("user");

        List<Car> cart = (List<Car>) session.getAttribute("cart");

        if (cart == null || cart.isEmpty()) {
            return "redirect:/cart";
        }

        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);

        for (Car car : cart) {

            Booking b = new Booking();
            b.setUserId(user.getId());
            b.setCarId(car.getId());
            b.setStartDate(start);
            b.setEndDate(end);
            b.setStatus("PENDING");

            bookingRepository.save(b);
        }

        session.removeAttribute("cart");

        return "redirect:/booking-success";
    }
}