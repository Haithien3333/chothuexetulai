package com.thuexe.thuexetulai.controller;

import com.thuexe.thuexetulai.model.Booking;
import com.thuexe.thuexetulai.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;
import com.thuexe.thuexetulai.model.User;
import java.util.List;

@Controller
public class BookingController {

    @Autowired
    private BookingRepository bookingRepository;

    @GetMapping("/booking-success")
    public String success(){
        return "booking-success";
    }


    @GetMapping("/booking/{carId}")
    public String bookCar(@PathVariable Long carId, HttpSession session) {

        Booking booking = new Booking();

        booking.setCarId(carId);
        User user = (User) session.getAttribute("user");

        booking.setUserId(user.getId());

        booking.setStartDate(LocalDate.now());
        booking.setEndDate(LocalDate.now().plusDays(1));

        booking.setStatus("PENDING");

        bookingRepository.save(booking);

        return "redirect:/booking-success";
    }

    @GetMapping("/payment/{id}")
    public String payment(@PathVariable Long id){

        Booking b = bookingRepository.findById(id).orElse(null);

        if(b != null){
            b.setStatus("PAID");
            bookingRepository.save(b);
        }

        return "redirect:/booking/history";
    }
    @GetMapping("/booking/history")
    public String history(HttpSession session, Model model) {

        User user = (User) session.getAttribute("user");

        List<Booking> list = bookingRepository.findAll()
                .stream()
                .filter(b -> b.getUserId().equals(user.getId()))
                .toList();

        model.addAttribute("bookings", list);

        return "history";
    }

}