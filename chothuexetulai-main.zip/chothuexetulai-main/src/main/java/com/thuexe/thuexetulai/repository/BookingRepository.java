package com.thuexe.thuexetulai.repository;

import com.thuexe.thuexetulai.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {
}